Download plugin zips and place them here when building to include them in
the container's GeoServer deployment.